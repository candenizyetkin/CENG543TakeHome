import os
import numpy as np
import torch
import torch.nn as nn
from datasets import load_dataset
from transformers import AutoTokenizer
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

# ---- Modelleri import et ----
from main_static import BiGRU as StaticBiGRU
from main_contextual import BertBiGRU as ContextualBiGRU, BERT_MODEL_NAME

# ======= Ortak ayarlar =======
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MAX_LEN_STATIC = 200   # main_static'te ne kullandıysan ona yakın tut
MAX_LEN_CTX = 128
N_PER_CLASS = 200      # her sınıftan kaç örnek alacağız


# ====================================================
# 1) STATIC TARAF: text -> ids (vocab + tokenizer yoksa bile)
# ====================================================

def simple_tokenize(text):
    # main_static'le birebir olmak zorunda değil, visualization için yeterli
    return text.lower().split()


def build_vocab_from_texts(texts, vocab_size=20000):
    from collections import Counter
    counter = Counter()
    for t in texts:
        counter.update(simple_tokenize(t))

    vocab = {"<PAD>": 0, "<UNK>": 1}
    for i, (w, _) in enumerate(counter.most_common(vocab_size - 2), start=2):
        vocab[w] = i
    return vocab


def encode_text_static(text, vocab, max_len):
    tokens = simple_tokenize(text)
    ids = [vocab.get(tok, vocab["<UNK>"]) for tok in tokens]
    if len(ids) < max_len:
        ids = ids + [vocab["<PAD>"]] * (max_len - len(ids))
    else:
        ids = ids[:max_len]
    return torch.tensor(ids, dtype=torch.long)


def collect_latents_static(model, texts, labels, vocab, max_len):
    model.eval()
    all_vecs = []
    all_labels = []

    with torch.no_grad():
        for text, y in zip(texts, labels):
            ids = encode_text_static(text, vocab, max_len).unsqueeze(0).to(DEVICE)
            h = model.encode(ids)           # (1, 2H)
            all_vecs.append(h.cpu().numpy())
            all_labels.append(y)

    X = np.concatenate(all_vecs, axis=0)
    y = np.array(all_labels)
    return X, y


# ====================================================
# 2) CONTEXTUAL TARAF: BERT tokenizer
# ====================================================

def collect_latents_contextual(model, texts, labels, tokenizer, max_len):
    model.eval()
    all_vecs = []
    all_labels = []

    with torch.no_grad():
        for text, y in zip(texts, labels):
            enc = tokenizer(
                text,
                padding="max_length",
                truncation=True,
                max_length=max_len,
                return_tensors="pt"
            )
            input_ids = enc["input_ids"].to(DEVICE)
            attention_mask = enc["attention_mask"].to(DEVICE)

            h = model.encode(input_ids=input_ids, attention_mask=attention_mask)  # (1, 2H)
            all_vecs.append(h.cpu().numpy())
            all_labels.append(y)

    X = np.concatenate(all_vecs, axis=0)
    y = np.array(all_labels)
    return X, y


# ====================================================
# 3) PCA + t-SNE PLOT (0 = BLUE, 1 = RED)
# ====================================================

def plot_pca_tsne(X, y, title_prefix, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    y = np.array(y).astype(int)

    # --- PCA ---
    pca = PCA(n_components=2, random_state=42)
    X_pca = pca.fit_transform(X)

    plt.figure(figsize=(6, 6))
    for val, color in [(0, "blue"), (1, "red")]:
        idx = (y == val)
        if np.sum(idx) == 0:
            continue
        plt.scatter(
            X_pca[idx, 0],
            X_pca[idx, 1],
            s=25,
            alpha=0.9,
            c=color,
            label=f"Label {val}",
        )
    plt.title(f"{title_prefix} - PCA")
    plt.legend()
    pca_path = os.path.join(out_dir, f"{title_prefix}_pca.png")
    plt.savefig(pca_path, dpi=300, bbox_inches="tight")
    plt.close()

    # --- t-SNE ---
    tsne = TSNE(n_components=2, perplexity=30, random_state=42)
    X_tsne = tsne.fit_transform(X)

    plt.figure(figsize=(6, 6))
    for val, color in [(0, "blue"), (1, "red")]:
        idx = (y == val)
        if np.sum(idx) == 0:
            continue
        plt.scatter(
            X_tsne[idx, 0],
            X_tsne[idx, 1],
            s=25,
            alpha=0.9,
            c=color,
            label=f"Label {val}",
        )
    plt.title(f"{title_prefix} - tSNE")
    plt.legend()
    tsne_path = os.path.join(out_dir, f"{title_prefix}_tsne.png")
    plt.savefig(tsne_path, dpi=300, bbox_inches="tight")
    plt.close()

    print("Saved:", pca_path)
    print("Saved:", tsne_path)


# ====================================================
# 4) MAIN
# ====================================================

def main():
    print("Loading IMDb test split...")
    ds = load_dataset("imdb")
    test_set = ds["test"]

    # Label 0 ve 1 için ayrı index listeleri
    idx_neg = [i for i, ex in enumerate(test_set) if ex["label"] == 0]
    idx_pos = [i for i, ex in enumerate(test_set) if ex["label"] == 1]

    # Her sınıftan N_PER_CLASS örnek seç
    idx_neg = idx_neg[:N_PER_CLASS]
    idx_pos = idx_pos[:N_PER_CLASS]
    indices = idx_neg + idx_pos

    texts = [test_set[i]["text"] for i in indices]
    labels = [test_set[i]["label"] for i in indices]

    print("Label distribution (selected):", np.unique(labels, return_counts=True))

    # ===== STATIC =====
    print("\n=== STATIC (BiGRU) ===")
    # vocab'i sadece bu seçilen textlerden kuruyoruz
    vocab = build_vocab_from_texts(texts)

    static_model = StaticBiGRU(
        vocab_size=len(vocab),
        embed_dim=300,
        hidden_size=128,
        num_layers=1,
        embedding_matrix=None,
        freeze_emb=False,
    ).to(DEVICE)

    X_static, y_static = collect_latents_static(static_model, texts, labels, vocab, MAX_LEN_STATIC)
    plot_pca_tsne(X_static, y_static, "static_bigru", os.path.join("outputs", "latent_static"))

    # ===== CONTEXTUAL =====
    print("\n=== CONTEXTUAL (BERT + BiGRU) ===")
    tokenizer_ctx = AutoTokenizer.from_pretrained(BERT_MODEL_NAME)

    ctx_model = ContextualBiGRU(
        bert_model_name=BERT_MODEL_NAME,
        rnn_hidden_size=128,
        num_layers=1,
        freeze_bert=True,
    ).to(DEVICE)

    X_ctx, y_ctx = collect_latents_contextual(ctx_model, texts, labels, tokenizer_ctx, MAX_LEN_CTX)
    plot_pca_tsne(X_ctx, y_ctx, "bert_bigru", os.path.join("outputs", "latent_contextual"))


if __name__ == "__main__":
    main()
