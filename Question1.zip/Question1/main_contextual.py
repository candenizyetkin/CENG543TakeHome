import random
import os
import json

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from datasets import load_dataset
from sklearn.metrics import accuracy_score, f1_score
from transformers import AutoTokenizer, AutoModel



# For REPRODUCIBILITY
def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False



# defining HYPERPARAMETERS
BERT_MODEL_NAME = "bert-base-uncased"

MAX_LEN = 128          # BERT sequence length
RNN_HIDDEN_SIZE = 128  # BiLSTM / BiGRU hidden size
NUM_LAYERS = 1

BATCH_SIZE = 16        
EPOCHS = 2             
LR = 2e-4              

USE_SUBSET = True
TRAIN_SUBSET = 8000
VAL_SUBSET = 2000

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# Setting up DATASET 
class IMDBTextDataset(Dataset):
    
    def __init__(self, hf_split):
        self.data = hf_split

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        example = self.data[idx]
        text = example["text"]
        label = example["label"]
        return text, label


def make_collate_fn(tokenizer, max_len: int):
    """
    Tokenizes a batch of raw text using the BERT tokenizer and
    converts the corresponding labels into tensors.

    - Applies padding and truncation to create uniform `input_ids`
      and `attention_mask` tensors.
    - Collects sentiment labels and returns them as a tensor.

    Used by the DataLoader to produce model-ready batches.
    """
    def collate(batch):
        texts = [b[0] for b in batch]
        labels = torch.tensor([b[1] for b in batch], dtype=torch.long)

        encodings = tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=max_len,
            return_tensors="pt",
        )
        input_ids = encodings["input_ids"]
        attention_mask = encodings["attention_mask"]

        return input_ids, attention_mask, labels

    return collate


# Setting up the MODELS
class BertBiLSTM(nn.Module):

    """
    A BERT-based text classification model.

    - Obtains contextual token representations from a pretrained BERT encoder.
    - Passes the sequence output through a bidirectional LSTM to capture
      sentence-level information from both directions.
    - Concatenates the final forward and backward hidden states to form the
      document representation.
    - Applies a linear layer to produce logits for binary sentiment prediction.

    The BERT encoder can be optionally frozen via `freeze_bert`.
    """

    def __init__(self, bert_model_name: str, rnn_hidden_size: int, num_layers: int = 1, freeze_bert: bool = True):
        super().__init__()

        self.bert = AutoModel.from_pretrained(bert_model_name)
        if freeze_bert:
            for p in self.bert.parameters():
                p.requires_grad = False

        bert_hidden_size = self.bert.config.hidden_size  

        self.lstm = nn.LSTM(
            input_size=bert_hidden_size,
            hidden_size=rnn_hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
        )

        self.fc = nn.Linear(2 * rnn_hidden_size, 2)  # binary classification

    def forward(self, input_ids, attention_mask):
        with torch.set_grad_enabled(any(p.requires_grad for p in self.bert.parameters())):
            bert_outputs = self.bert(
                input_ids=input_ids,
                attention_mask=attention_mask,
            )
        # last_hidden_state: (B, T, H_bert)
        sequence_output = bert_outputs.last_hidden_state

        lstm_out, (h_n, c_n) = self.lstm(sequence_output) 

        # son layer'ın forward/backward state'lerini al
        h_forward = h_n[-2, :, :]
        h_backward = h_n[-1, :, :]
        h_cat = torch.cat([h_forward, h_backward], dim=-1)  # (B, 2*H_rnn)

        logits = self.fc(h_cat)  # (B, 2)
        return logits


class BertBiGRU(nn.Module):

    """
    A BERT-based text classification model that uses a bidirectional GRU
    on top of BERT's contextual token embeddings.

    - Extracts the last hidden states from a pretrained BERT encoder.
    - Processes the token sequence with a bidirectional GRU to capture
      global sentence-level information.
    - Concatenates the final forward and backward GRU hidden states to form
      the document representation.
    - Applies a linear classifier to produce logits for binary sentiment labels.

    The BERT encoder can be optionally frozen using `freeze_bert`.
    """

    def __init__(self, bert_model_name: str, rnn_hidden_size: int, num_layers: int = 1, freeze_bert: bool = True):
        super().__init__()

        self.bert = AutoModel.from_pretrained(bert_model_name)
        if freeze_bert:
            for p in self.bert.parameters():
                p.requires_grad = False

        bert_hidden_size = self.bert.config.hidden_size

        self.gru = nn.GRU(
            input_size=bert_hidden_size,
            hidden_size=rnn_hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
        )

        self.fc = nn.Linear(2 * rnn_hidden_size, 2)

    def forward(self, input_ids, attention_mask):
        with torch.no_grad():  # frozen BERT
            bert_outputs = self.bert(
                input_ids=input_ids,
                attention_mask=attention_mask,
            )

        sequence_output = bert_outputs.last_hidden_state 

        gru_out, h_n = self.gru(sequence_output)       

        h_forward = h_n[-2, :, :]
        h_backward = h_n[-1, :, :]
        h_cat = torch.cat([h_forward, h_backward], dim=-1)

        logits = self.fc(h_cat)
        return logits

    def encode(self, input_ids, attention_mask):

        """
        Computes the latent sentence representation used for analysis.

        - Runs the input through the (frozen) BERT encoder to obtain contextual
        token embeddings.
        - Passes these embeddings through the bidirectional GRU.
        - Concatenates the final forward and backward hidden states to form
        the document-level vector (h_cat).

        Returns:
        Tensor of shape (batch_size, 2 * hidden_size): the latent representation.
         """
        with torch.no_grad():
            bert_outputs = self.bert(
                input_ids=input_ids,
                attention_mask=attention_mask,
            )
            sequence_output = bert_outputs.last_hidden_state

            gru_out, h_n = self.gru(sequence_output)

            h_forward = h_n[-2, :, :]
            h_backward = h_n[-1, :, :]
            h_cat = torch.cat([h_forward, h_backward], dim=-1)

        return h_cat



#TRAIN / EVAL FUNC for the CONTEXTUAL Model
def train_one_epoch_ctx(model, loader, optimizer, criterion, device):
    
      """
    Trains the contextual (BERT-based) model for one epoch.

    - Moves all batch inputs (input_ids, attention_mask, labels) to the
      specified device.
    - Performs a forward pass through BERT + GRU/LSTM.
    - Computes the loss, runs backpropagation, and updates model parameters.
    - Accumulates and returns the average training loss over the epoch.

    This function is used for the training phase only (model.train()).
    """

    model.train()
    total_loss = 0.0

    for input_ids, attention_mask, labels in loader:
        input_ids = input_ids.to(device)
        attention_mask = attention_mask.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()
        logits = model(input_ids=input_ids, attention_mask=attention_mask)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(loader)



def evaluate_ctx(model, loader, criterion, device):

    """
    Evaluates the contextual model on a validation or test set.

    - Disables gradient computation (model.eval()).
    - Runs forward passes to compute predictions and loss.
    - Collects predicted labels and true labels to compute accuracy
      and macro-F1 score.
    - Returns the average loss, accuracy, and macro-F1 over the dataset.

    Used for validation/testing—no training or parameter updates occur here.
    """

    model.eval()
    total_loss = 0.0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for input_ids, attention_mask, labels in loader:
            input_ids = input_ids.to(device)
            attention_mask = attention_mask.to(device)
            labels = labels.to(device)

            logits = model(input_ids=input_ids, attention_mask=attention_mask)
            loss = criterion(logits, labels)
            total_loss += loss.item()

            preds = torch.argmax(logits, dim=-1)
            all_preds.extend(preds.cpu().numpy().tolist())
            all_labels.extend(labels.cpu().numpy().tolist())

    avg_loss = total_loss / len(loader)
    acc = accuracy_score(all_labels, all_preds)
    macro_f1 = f1_score(all_labels, all_preds, average="macro")

    return avg_loss, acc, macro_f1


#JSON LOGGING
def save_json(data, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=4)


# MAIN FLOW
def main():
    """
    Main entry point for training and evaluating the contextual models
    (BERT + BiLSTM and BERT + BiGRU) on the IMDb sentiment dataset.

    The function:
    - Loads and splits the dataset,
    - Builds DataLoaders with a BERT tokenizer,
    - Trains both models for a fixed number of epochs,
    - Evaluates them on the test set,
    - Logs all metrics to a JSON file for later analysis.
    """
    print("Device:", DEVICE)
    set_seed(42)

    # IMDb DATASET LOADING AND SPLIT
    print("Loading IMDb dataset...")
    ds = load_dataset("imdb")

    # Fixed train/validation split for reproducibility
    split = ds["train"].train_test_split(test_size=0.15, seed=42)
    train_ds_hf = split["train"]
    val_ds_hf = split["test"]
    test_ds_hf = ds["test"]

    # Optional: work on a subset for faster debugging
    if USE_SUBSET:
        print(f"Using subset: train={TRAIN_SUBSET}, val={VAL_SUBSET}")
        train_ds_hf = train_ds_hf.select(range(TRAIN_SUBSET))
        val_ds_hf = val_ds_hf.select(range(VAL_SUBSET))

    print("Train:", len(train_ds_hf), "Val:", len(val_ds_hf), "Test:", len(test_ds_hf))

    # ---- 2) DATASETS, TOKENIZER AND DATALOADERS ----
    print("Loading tokenizer and creating datasets/loaders...")
    tokenizer = AutoTokenizer.from_pretrained(BERT_MODEL_NAME)

    # Wrap HuggingFace datasets in lightweight Dataset classes
    train_dataset = IMDBTextDataset(train_ds_hf)
    val_dataset = IMDBTextDataset(val_ds_hf)
    test_dataset = IMDBTextDataset(test_ds_hf)

    # Custom collate_fn: tokenizes raw text into BERT inputs + label tensors
    collate_fn = make_collate_fn(tokenizer, MAX_LEN)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True,  collate_fn=collate_fn)
    val_loader   = DataLoader(val_dataset,   batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)
    test_loader  = DataLoader(test_dataset,  batch_size=BATCH_SIZE, shuffle=False, collate_fn=collate_fn)

    # Shared loss function for all contextual models
    criterion = nn.CrossEntropyLoss()

    # JSON logging structure for all results
    logs = {
        "bilstm_bert": {
            "epochs": []
        },
        "bigru_bert": {
            "epochs": []
        }
    }

    # Base directory and output path (kept relative for reproducibility)
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

    # train BERT + BiLSTM
    print("\n===== Training BERT + BiLSTM (contextual embeddings) =====")
    bilstm_bert = BertBiLSTM(
        bert_model_name=BERT_MODEL_NAME,
        rnn_hidden_size=RNN_HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
        freeze_bert=True,  # keep BERT frozen; only RNN + FC are trained
    ).to(DEVICE)

    # Only update parameters that are marked as trainable
    optimizer_bilstm = torch.optim.Adam(
        filter(lambda p: p.requires_grad, bilstm_bert.parameters()),
        lr=LR
    )

    best_val_f1 = 0.0
    for epoch in range(1, EPOCHS + 1):
        train_loss = train_one_epoch_ctx(bilstm_bert, train_loader, optimizer_bilstm, criterion, DEVICE)
        val_loss, val_acc, val_f1 = evaluate_ctx(bilstm_bert, val_loader, criterion, DEVICE)

        print(
            f"[BERT+BiLSTM] Epoch {epoch}/{EPOCHS} | "
            f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | "
            f"Val Acc: {val_acc:.4f} | Val Macro-F1: {val_f1:.4f}"
        )

        # Log epoch-level metrics for later analysis
        logs["bilstm_bert"]["epochs"].append({
            "epoch": epoch,
            "train_loss": float(train_loss),
            "val_loss": float(val_loss),
            "val_acc": float(val_acc),
            "val_macro_f1": float(val_f1),
        })

        # Track the best validation F1 (if early stopping / model saving is needed)
        if val_f1 > best_val_f1:
            best_val_f1 = val_f1

    # Final evaluation on the held-out test set
    test_loss, test_acc, test_f1 = evaluate_ctx(bilstm_bert, test_loader, criterion, DEVICE)
    print(
        f"[BERT+BiLSTM] Test Loss: {test_loss:.4f} | "
        f"Test Acc: {test_acc:.4f} | Test Macro-F1: {test_f1:.4f}"
    )

    logs["bilstm_bert"]["test"] = {
        "test_loss": float(test_loss),
        "test_acc": float(test_acc),
        "test_macro_f1": float(test_f1),
    }

    # Training BERT + BiGRU
    print("\n===== Training BERT + BiGRU (contextual embeddings) =====")
    bigru_bert = BertBiGRU(
        bert_model_name=BERT_MODEL_NAME,
        rnn_hidden_size=RNN_HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
        freeze_bert=True,
    ).to(DEVICE)

    optimizer_bigru = torch.optim.Adam(
        filter(lambda p: p.requires_grad, bigru_bert.parameters()),
        lr=LR
    )

    best_val_f1 = 0.0
    for epoch in range(1, EPOCHS + 1):
        train_loss = train_one_epoch_ctx(bigru_bert, train_loader, optimizer_bigru, criterion, DEVICE)
        val_loss, val_acc, val_f1 = evaluate_ctx(bigru_bert, val_loader, criterion, DEVICE)

        print(
            f"[BERT+BiGRU] Epoch {epoch}/{EPOCHS} | "
            f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | "
            f"Val Acc: {val_acc:.4f} | Val Macro-F1: {val_f1:.4f}"
        )

        logs["bigru_bert"]["epochs"].append({
            "epoch": epoch,
            "train_loss": float(train_loss),
            "val_loss": float(val_loss),
            "val_acc": float(val_acc),
            "val_macro_f1": float(val_f1),
        })

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1

    test_loss, test_acc, test_f1 = evaluate_ctx(bigru_bert, test_loader, criterion, DEVICE)
    print(
        f"[BERT+BiGRU] Test Loss: {test_loss:.4f} | "
        f"Test Acc: {test_acc:.4f} | Test Macro-F1: {test_f1:.4f}"
    )

    logs["bigru_bert"]["test"] = {
        "test_loss": float(test_loss),
        "test_acc": float(test_acc),
        "test_macro_f1": float(test_f1),
    }

    # save JSON LOGS
    out_path = os.path.join(BASE_DIR, "outputs", "contextual_results.json")
    save_json(logs, out_path)
    print(f"\nSaved JSON logs to {out_path}")


if __name__ == "__main__":
    main()