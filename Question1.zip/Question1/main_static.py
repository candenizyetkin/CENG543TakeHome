import random
import numpy as np
from collections import Counter
import json
import os

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from datasets import load_dataset
from sklearn.metrics import accuracy_score, f1_score

import gensim.downloader as api


def set_seed(seed: int = 42):
    """
    Sets all relevant random seeds (Python, NumPy, PyTorch) and configures
    cuDNN to enable deterministic behavior for reproducible experiments.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


#setting HYPERPARAMETERS
MAX_VOCAB_SIZE = 20000
MAX_LEN = 256
EMBED_DIM = 300
HIDDEN_SIZE = 128
NUM_LAYERS = 1
BATCH_SIZE = 64
EPOCHS = 3          # kept small for assignment-level training time
LR = 1e-3

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")



# defining TOKENIZER
def tokenizer(text: str):
    """
    Simple whitespace-based tokenizer used for the static (GloVe) models.

    Lowercases the input text and splits on spaces. This is sufficient for
    IMDb sentiment analysis in this assignment setting.
    """
    return text.lower().split()


#setting up DATASET CLASS
class IMDBStaticDataset(Dataset):
    """
    Torch Dataset wrapper around the IMDb split for static embeddings.

    - Converts raw text into integer token IDs using a fixed vocabulary.
    - Applies truncation/padding to a fixed maximum sequence length.
    - Returns (input_ids, label) pairs suitable for static models.
    """
    def __init__(self, hf_split, vocab, max_len: int = 256):
        self.data = hf_split
        self.vocab = vocab
        self.max_len = max_len
        self.unk_id = vocab["<UNK>"]
        self.pad_id = vocab["<PAD>"]

    def __len__(self):
        return len(self.data)

    def encode(self, text: str):
        tokens = tokenizer(text)
        ids = [self.vocab.get(tok, self.unk_id) for tok in tokens]

        # Truncate
        if len(ids) > self.max_len:
            ids = ids[: self.max_len]

        # Pad
        if len(ids) < self.max_len:
            ids = ids + [self.pad_id] * (self.max_len - len(ids))

        return torch.tensor(ids, dtype=torch.long)

    def __getitem__(self, idx):
        example = self.data[idx]
        text = example["text"]
        label = example["label"]  # 0 or 1

        x = self.encode(text)
        y = torch.tensor(label, dtype=torch.long)
        return x, y


# MODELS
class BiLSTM(nn.Module):
    """
    Bidirectional LSTM classifier using static word embeddings (e.g., GloVe).

    - Looks up token embeddings for each input ID.
    - Processes the sequence with a bidirectional LSTM.
    - Concatenates the final forward and backward hidden states.
    - Applies a linear layer to produce logits for binary sentiment labels.
    """
    def __init__(self, vocab_size, embed_dim, hidden_size, num_layers,
                 embedding_matrix=None, freeze_emb=True):
        super().__init__()

        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)

        if embedding_matrix is not None:
            self.embedding.weight.data.copy_(torch.from_numpy(embedding_matrix))
        if freeze_emb:
            self.embedding.weight.requires_grad = False

        self.lstm = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
        )
        self.fc = nn.Linear(2 * hidden_size, 2)  # binary classification

    def forward(self, x):
        emb = self.embedding(x)                  # (B, T, E)
        output, (h_n, c_n) = self.lstm(emb)      # h_n: (num_layers*2, B, H)

        # Take the last layer's forward and backward hidden states
        h_forward = h_n[-2, :, :]
        h_backward = h_n[-1, :, :]
        h_cat = torch.cat([h_forward, h_backward], dim=-1)  # (B, 2H)

        logits = self.fc(h_cat)                 # (B, 2)
        return logits


class BiGRU(nn.Module):
    """
    Bidirectional GRU classifier using static word embeddings (e.g., GloVe).

    - Uses an embedding layer initialized with a GloVe-based matrix.
    - Processes sequences with a bidirectional GRU.
    - Concatenates the final forward and backward hidden states.
    - Applies a linear layer for binary classification.
    """
    def __init__(self, vocab_size, embed_dim, hidden_size, num_layers,
                 embedding_matrix=None, freeze_emb=True):
        super().__init__()

        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)

        if embedding_matrix is not None:
            self.embedding.weight.data.copy_(torch.from_numpy(embedding_matrix))
        if freeze_emb:
            self.embedding.weight.requires_grad = False

        self.gru = nn.GRU(
            input_size=embed_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
        )

        self.fc = nn.Linear(2 * hidden_size, 2)

    def forward(self, x):
        emb = self.embedding(x)
        output, h_n = self.gru(emb)

        h_forward = h_n[-2, :, :]
        h_backward = h_n[-1, :, :]
        h_cat = torch.cat([h_forward, h_backward], dim=-1)

        logits = self.fc(h_cat)
        return logits

    def encode(self, x):
        """
        Returns the latent document representation (h_cat) without classification.

        This is used later for analysis and visualization (e.g., PCA / t-SNE).
        """
        emb = self.embedding(x)
        output, h_n = self.gru(emb)

        h_forward = h_n[-2, :, :]
        h_backward = h_n[-1, :, :]
        h_cat = torch.cat([h_forward, h_backward], dim=-1)

        return h_cat



#TRAIN / EVAL HELPERS
def train_one_epoch(model, loader, optimizer, criterion, device):
    """
    Trains a static model (BiLSTM or BiGRU) for one epoch.

    - Loops over the DataLoader batches.
    - Computes logits, loss, and performs a backward pass.
    - Updates parameters using the given optimizer.
    - Returns the average training loss over the epoch.
    """
    model.train()
    total_loss = 0.0

    for batch_x, batch_y in loader:
        batch_x = batch_x.to(device)
        batch_y = batch_y.to(device)

        optimizer.zero_grad()
        logits = model(batch_x)
        loss = criterion(logits, batch_y)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    return total_loss / len(loader)


def evaluate(model, loader, criterion, device):
    """
    Evaluates a static model on a validation or test split.

    - Disables gradient computation.
    - Computes average loss over the split.
    - Collects predictions and labels to compute accuracy and macro-F1.
    """
    model.eval()
    total_loss = 0.0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for batch_x, batch_y in loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)

            logits = model(batch_x)
            loss = criterion(logits, batch_y)
            total_loss += loss.item()

            preds = torch.argmax(logits, dim=-1)
            all_preds.extend(preds.cpu().numpy().tolist())
            all_labels.extend(batch_y.cpu().numpy().tolist())

    avg_loss = total_loss / len(loader)
    acc = accuracy_score(all_labels, all_preds)
    macro_f1 = f1_score(all_labels, all_preds, average="macro")

    return avg_loss, acc, macro_f1



#JSON LOGGING
def save_json(data, path):
    """
    Saves experiment logs (metrics, hyperparameters, etc.) as a JSON file.

    Creates parent directories if they do not exist.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=4)



#MAIN PIPELINE
def main():
    """
    Main entry point for training and evaluating the static embedding models
    (BiLSTM and BiGRU) on the IMDb sentiment dataset.

    Steps:
    1. Load and split the IMDb data.
    2. Build a vocabulary and GloVe-based embedding matrix.
    3. Construct PyTorch datasets and dataloaders.
    4. Train BiLSTM and BiGRU models.
    5. Evaluate them on the test set.
    6. Log all results to a JSON file for later analysis.
    """
    print("Device:", DEVICE)
    set_seed(42)

    #IMDb DATASET
    print("Loading IMDb dataset...")
    ds = load_dataset("imdb")

    # Fixed train/validation split for reproducibility
    split = ds["train"].train_test_split(test_size=0.15, seed=42)
    train_ds_hf = split["train"]
    val_ds_hf = split["test"]
    test_ds_hf = ds["test"]

    print("Train:", len(train_ds_hf), "Val:", len(val_ds_hf), "Test:", len(test_ds_hf))

    #VOCAB BUILDING
    print("Building vocabulary...")
    counter = Counter()
    for example in train_ds_hf:
        counter.update(tokenizer(example["text"]))

    most_common = counter.most_common(MAX_VOCAB_SIZE - 2)  # 2 special tokens
    vocab = {"<PAD>": 0, "<UNK>": 1}
    for i, (word, freq) in enumerate(most_common, start=2):
        vocab[word] = i

    vocab_size = len(vocab)
    print("Vocab size:", vocab_size)

    #GLOVE EMBEDDING MATRIX
    print("Loading GloVe embeddings (this may take a bit)...")
    glove = api.load("glove-wiki-gigaword-300")

    embedding_matrix = np.zeros((vocab_size, EMBED_DIM), dtype=np.float32)
    oov_count = 0

    for word, idx in vocab.items():
        if word in glove:
            embedding_matrix[idx] = glove[word]
        else:
            # Random initialization for out-of-vocabulary words
            embedding_matrix[idx] = np.random.normal(scale=0.6, size=(EMBED_DIM,))
            oov_count += 1

    print(f"OOV words: {oov_count} / {vocab_size}")

    #TORCH DATASET & DATALOADER
    train_dataset = IMDBStaticDataset(train_ds_hf, vocab, max_len=MAX_LEN)
    val_dataset = IMDBStaticDataset(val_ds_hf, vocab, max_len=MAX_LEN)
    test_dataset = IMDBStaticDataset(test_ds_hf, vocab, max_len=MAX_LEN)

    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

    # Shared loss function for both static models
    criterion = nn.CrossEntropyLoss()

    # JSON log structure
    logs = {
        "bilstm": {
            "epochs": []
        },
        "bigru": {
            "epochs": []
        }
    }

    #BiLSTM TRAINING
    print("\n===== Training BiLSTM (static embeddings) =====")
    bilstm = BiLSTM(
        vocab_size=vocab_size,
        embed_dim=EMBED_DIM,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
        embedding_matrix=embedding_matrix,
        freeze_emb=True,  # static embedding
    ).to(DEVICE)

    optimizer_bilstm = torch.optim.Adam(
        filter(lambda p: p.requires_grad, bilstm.parameters()),
        lr=LR
    )

    best_val_f1 = 0.0
    for epoch in range(1, EPOCHS + 1):
        train_loss = train_one_epoch(bilstm, train_loader, optimizer_bilstm, criterion, DEVICE)
        val_loss, val_acc, val_f1 = evaluate(bilstm, val_loader, criterion, DEVICE)

        print(
            f"[BiLSTM] Epoch {epoch}/{EPOCHS} | "
            f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | "
            f"Val Acc: {val_acc:.4f} | Val Macro-F1: {val_f1:.4f}"
        )

        # Log epoch-level metrics
        logs["bilstm"]["epochs"].append({
            "epoch": epoch,
            "train_loss": float(train_loss),
            "val_loss": float(val_loss),
            "val_acc": float(val_acc),
            "val_macro_f1": float(val_f1),
        })

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1

    # Final test performance
    test_loss, test_acc, test_f1 = evaluate(bilstm, test_loader, criterion, DEVICE)
    print(
        f"[BiLSTM] Test Loss: {test_loss:.4f} | "
        f"Test Acc: {test_acc:.4f} | Test Macro-F1: {test_f1:.4f}"
    )

    logs["bilstm"]["test"] = {
        "test_loss": float(test_loss),
        "test_acc": float(test_acc),
        "test_macro_f1": float(test_f1),
    }

    # BiGRU TRAINING
    print("\n===== Training BiGRU (static embeddings) =====")
    bigru = BiGRU(
        vocab_size=vocab_size,
        embed_dim=EMBED_DIM,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
        embedding_matrix=embedding_matrix,
        freeze_emb=True,
    ).to(DEVICE)

    optimizer_bigru = torch.optim.Adam(
        filter(lambda p: p.requires_grad, bigru.parameters()),
        lr=LR
    )

    best_val_f1 = 0.0
    for epoch in range(1, EPOCHS + 1):
        train_loss = train_one_epoch(bigru, train_loader, optimizer_bigru, criterion, DEVICE)
        val_loss, val_acc, val_f1 = evaluate(bigru, val_loader, criterion, DEVICE)

        print(
            f"[BiGRU] Epoch {epoch}/{EPOCHS} | "
            f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | "
            f"Val Acc: {val_acc:.4f} | Val Macro-F1: {val_f1:.4f}"
        )

        logs["bigru"]["epochs"].append({
            "epoch": epoch,
            "train_loss": float(train_loss),
            "val_loss": float(val_loss),
            "val_acc": float(val_acc),
            "val_macro_f1": float(val_f1),
        })

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1

    # Final test performance
    test_loss, test_acc, test_f1 = evaluate(bigru, test_loader, criterion, DEVICE)
    print(
        f"[BiGRU] Test Loss: {test_loss:.4f} | "
        f"Test Acc: {test_acc:.4f} | Test Macro-F1: {test_f1:.4f}"
    )

    logs["bigru"]["test"] = {
        "test_loss": float(test_loss),
        "test_acc": float(test_acc),
        "test_macro_f1": float(test_f1),
    }

    # save JSON LOGS
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    out_path = os.path.join(BASE_DIR, "outputs", "static_results.json")
    save_json(logs, out_path)
    print(f"\nSaved JSON logs to {out_path}")


if __name__ == "__main__":
    main()
