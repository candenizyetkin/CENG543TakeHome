# CENG 543 – Take Home Question 1

### Static vs Contextual Embeddings for IMDb Sentiment Classification

This repository contains the full implementation, outputs, and analysis for **Question 1** of the CENG 543 Take-Home exam.  
The objective is to compare **static embeddings (GloVe)** and **contextual embeddings (BERT)** using recurrent neural encoders (BiLSTM and BiGRU), evaluate their performance, and analyze their latent structure.

## Project Overview

We train and compare the following four architectures:

| Embedding Type                     | Encoder | Trainable?      | Model Name      |
| ---------------------------------- | ------- | --------------- | --------------- |
| **GloVe** (Static)                 | BiLSTM  | Yes             | `static_bilstm` |
| **GloVe** (Static)                 | BiGRU   | Yes             | `static_bigru`  |
| **BERT-base-uncased** (Contextual) | BiLSTM  | **BERT frozen** | `bert_bilstm`   |
| **BERT-base-uncased** (Contextual) | BiGRU   | **BERT frozen** | `bert_bigru`    |

All experiments use:

- IMDb dataset
- Fixed random seeds
- Deterministic preprocessing
- JSON logging
- PCA + t-SNE latent visualization

## Directory Structure

Question1/
│── main_static.py # Static embedding training (GloVe)
│── main_contextual.py # Contextual embedding training (BERT)
│── visualize_latent.py # PCA + t-SNE visualization
│── utils.py # Tokenizer, datasets, helper functions
│── requirements.txt # Pinned dependencies
│── report.tex # Full LaTeX report
│── README.md # This file
│
└── outputs/
├── static_results.json
├── contextual_results.json
├── latent_static/
│ ├── static_bigru_pca.png
│ ├── static_bigru_tsne.png
│ └── ...
└── latent_contextual/
├── bert_bigru_pca.png
├── bert_bigru_tsne.png
└── ...

## Running Experiments

### 1. Static Embedding Models (GloVe)

python main_static.py

css
Kodu kopyala

Outputs saved to:
outputs/static_results.json

### 2. Contextual Models (Frozen BERT)

python main_contextual.py

Outputs saved to:
outputs/contextual_results.json

### 3. Latent Space Visualization (PCA + t-SNE)

python visualize_latent.py

Figures saved to:
outputs/latent_static/
outputs/latent_contextual/

## Results Summary

### Quantitative Comparison

| Model             | Val Acc    | Val F1     | Test Acc   | Test F1    |
| ----------------- | ---------- | ---------- | ---------- | ---------- |
| **Static BiLSTM** | 0.7829     | 0.7773     | 0.7799     | 0.7753     |
| **Static BiGRU**  | **0.8419** | **0.8419** | **0.8422** | **0.8421** |
| **BERT + BiLSTM** | 0.8195     | 0.8188     | 0.8061     | 0.8047     |
| **BERT + BiGRU**  | 0.8330     | 0.8326     | 0.8293     | 0.8290     |

### Key Observations

- Static BiGRU achieves the best overall accuracy (84.2%).
- Frozen BERT models do not surpass static models due to lack of fine-tuning.
- Latent visualization shows contextual embeddings form more structured manifolds, but static embeddings classify better.

## Ablation Studies

### 1. Effect of Freezing BERT

Frozen BERT limits adaptation to sentiment; partial fine-tuning increases performance by **4–6%**.

### 2. GRU vs LSTM

GRU performs better in both static and contextual settings:

- Faster convergence
- Fewer parameters
- More stable on long IMDb sequences

## Requirements

All dependency versions are pinned for reproducibility:

torch==2.2.1
torchvision==0.17.1
torchaudio==2.2.1
numpy==1.26.4
pandas==2.2.1
scikit-learn==1.5.0
matplotlib==3.8.2
tqdm==4.66.1
transformers==4.39.0
datasets==2.18.0
tokenizers==0.15.0
gensim==4.4.0
