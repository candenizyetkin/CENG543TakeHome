# Question 5 — Explainability and Uncertainty Analysis

### _Static BiGRU (GloVe) Sentiment Classifier_

This repository contains the full reproducible pipeline developed for **Question 5**, focusing on interpretability and uncertainty estimation for the **best-performing model selected in Question 1**.  
The entire workflow runs end-to-end inside a **single Google Colab notebook**, with no external scripts required.

All outputs (logs, figures, JSON files) are automatically saved under:

/content/drive/MyDrive/TakeHome543/Question5/

## 1. Objective

The goal of Question 5 is to perform a detailed interpretability and uncertainty analysis on the **best model identified earlier**.  
From Question 1 experiments, the best model is:

### ✔ **Static BiGRU (GloVe embeddings, frozen)**

- Test Accuracy: **84.22%**
- Test Macro-F1: **84.21**

The analysis covers:

- Predictive **uncertainty** (entropy, confidence, calibration)
- **Failure case** identification
- **Integrated Gradients (IG)** for token-level attribution
- Generation of publication-ready **figures**, **tables**, and **JSON logs**

## 2. Environment & Requirements

The pipeline is designed for **Google Colab** and requires only the following libraries:

pip install datasets gensim transformers rank-bm25
No additional system dependencies or external files are required.
The entire dataset (IMDb) is loaded dynamically through HuggingFace Datasets.

3. Directory Structure (Generated Automatically)
   After running the notebook, you will find:

Question5/
static_bigru_imdb.pt # Model weights
static_bigru_imdb_logs.json # Training/validation metrics
static_bigru_imdb_test_predictions.json # Per-example predictions
static_bigru_imdb_calibration.json # Confidence–accuracy bins
static_bigru_imdb_uncertainty_summary.json
static_bigru_imdb_failure_cases.json # Top-5 high/low entropy errors
static_bigru_ig_metadata.json # Tokens + IG scores
figures/
ig_high_entropy_wrong_0.png # IG heatmap #1
ig_low_entropy_wrong_0.png # IG heatmap #2
All files are created automatically when running the notebook.

4. Pipeline Overview
   Step 1 — Load IMDb Dataset
   Dataset automatically pulled from HuggingFace.

Train/validation split uses deterministic seed=42.

Step 2 — Build Vocabulary + Load GloVe
300d GloVe vectors loaded via gensim.

Vocabulary capped at 20,000 tokens.

<PAD> and <UNK> tokens included.

Step 3 — Model Initialization
Embedding layer initialized with GloVe vectors (frozen).

Bidirectional GRU (hidden size = 128).

Final classification head outputs two sentiment logits.

Step 4 — Training & Evaluation
3 epochs, batch size 64, Adam optimizer.

Best validation macro-F1 checkpoint saved.

Test set predictions stored for downstream analysis.

Step 5 — Uncertainty Estimation
The notebook computes:

Softmax confidence

Predictive entropy

Calibration bins (10 bins)

Failure case categorization:

High-entropy wrong predictions

Low-entropy wrong predictions (overconfident errors)

All results saved as JSON.

Step 6 — Integrated Gradients (IG)
A custom IG implementation (no Captum required) computes:

Token-level attribution scores

Positive vs. negative contributions

Heatmaps visualized via Matplotlib

Two representative figures are generated:

ig_high_entropy_wrong_0.png

ig_low_entropy_wrong_0.png

These figures are meant for inclusion in the final LaTeX report.

5. How to Run the Notebook (Step-by-Step)
   Open the Colab notebook.

Mount Google Drive:

from google.colab import drive
drive.mount('/content/drive')
Install dependencies:

!pip install datasets gensim

Run the notebook cells top to bottom.
All:

training,

prediction,

test analysis,

IG attribution,

plotting
will execute automatically.

After execution, navigate to:

/content/drive/MyDrive/TakeHome543/Question5/
