# Question 3 — Seq2Seq vs Transformer (Reproducibility Guide)

This repository contains a fully reproducible pipeline for comparing a Bahdanau-style recurrent Seq2Seq model and a Transformer encoder–decoder on the Quora paraphrase generation task.

## 1. Environment Setup

Use Google Colab or local GPU with:

pip install datasets sacrebleu rouge-score
pip install torch --index-url https://download.pytorch.org/whl/cu118

## 2. Directory Structure

The notebook automatically creates:

/Question3/
data/
vocab/
checkpoints/
logs/
figs/

All artifacts (JSON logs, model weights, attention images, ablation results) are stored here.

## 3. Dataset

We use the Quora Question Pairs dataset filtered to paraphrases:

- Train: 80%
- Validation: 10%
- Test: 10%

Tokenization:

- lowercasing, whitespace split
- max length = 30
- shared vocabulary built only from training set

## 4. Models

### Bahdanau Seq2Seq

- BiLSTM encoder (256 hidden, 1 layer)
- LSTM decoder (256 hidden)
- Additive attention
- CrossEntropyLoss with PAD ignored

### Transformer

- d_model = 256
- 3 encoder + 3 decoder layers
- 4 attention heads
- FFN = 512
- Sinusoidal positional encoding

## 5. Training

Common settings:

- Batch size: 64
- LR = 1e-3
- Optimizer: Adam
- Teacher forcing with shifted decoder targets
- Greedy decoding during evaluation

## 6. Evaluation

Metrics computed on test split:

- BLEU (SacreBLEU)
- ROUGE-L (rouge-score)
- Perplexity
- Evaluation time
- CUDA peak memory

All results are saved under:

Question3/logs/

## 7. Ablation Study

We run four Transformer variants:

- L2_H2
- L2_H4
- L4_H4
- L6_H8

Each trained for 5 epochs.

Results stored in:

transformer*ablation_results.json
ablation_history*\*.json

and summarized into BLEU/time plots under `figs/`.

## 8. Reproducing Figures

Figures generated:

- bahdanau_loss.png
- transformer_loss.png
- ablation_bleu_vs_config.png
- ablation_time_vs_config.png

## 9. Checkpoints

All trained model weights are saved to:

Question3/checkpoints/
