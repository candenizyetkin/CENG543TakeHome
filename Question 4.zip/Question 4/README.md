# Retrieval-Augmented Generation on HotpotQA

### CENG543 – Take Home Exam (Question 4)

This repository contains a fully reproducible **Retrieval-Augmented Generation (RAG)** pipeline built in a **single Google Colab notebook**.  
The system integrates **sparse retrieval models** (BM25, TF–IDF) with a **sequence-to-sequence generator** (FLAN-T5-small) and evaluates the overall RAG performance using multiple metrics.

The goal is not to achieve state-of-the-art results, but to implement, evaluate, and analyze a complete RAG system in accordance with the Question 4 requirements.

## 1. Features

This project provides:

- A clean **RAG pipeline** combining:

  - BM25 retriever
  - TF–IDF retriever
  - FLAN-T5-small generator

- Full **evaluation protocol** for:

  - Precision@k, Recall@k (retrieval)
  - BLEU, ROUGE-L, BERTScore (generation)

- **Qualitative analysis** of:

  - Faithful grounded answers
  - Hallucinated answers even under correct retrieval

- **JSON logging** for reproducibility:

  - `rag_results_summary.json`
  - `rag_qualitative_examples_bm25.json`

- **Visualization** (PNG figures):

  - Retrieval metrics bar chart
  - Generation metrics bar chart

- Entire workflow inside **one notebook**, no external files required.

## 2. Environment & Dependencies

Runs on **Google Colab** (GPU recommended but optional).

Install all dependencies via:

```python
!pip install -q datasets transformers rank-bm25 scikit-learn \
    rouge-score sacrebleu bert-score sentence-transformers
Required Python packages include:

datasets

transformers

rank-bm25

scikit-learn

torch

rouge-score

sacrebleu

bert-score

numpy

No additional configuration is necessary.

3. Reproducibility Guarantee
To ensure experiment reproducibility:

All randomness is controlled via:


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
The notebook uses deterministic generation settings (beam search).

All evaluation results are exported to JSON files.

The dataset slice is fixed (validation[:200]).

Running all cells from top to bottom yields identical results.

4. Dataset
We use the HotpotQA "distractor" validation split via HuggingFace Datasets:

raw_dataset = load_dataset("hotpot_qa", "distractor", split="validation[:200]")
For each example we keep:

question

answer

context paragraphs

supporting fact titles (for retrieval metrics)

Data is automatically preprocessed in the notebook — no external files required.

5. System Architecture
Sparse Retrieval
Two retrievers are implemented:

BM25 using rank-bm25

TF–IDF using sklearn.TfidfVectorizer

The HotpotQA context is flattened into a document corpus of:

"TITLE. sentence1 sentence2 ..."
Both retrievers return the top-k relevant passages.

Generator
We use:

MODEL_NAME = "google/flan-t5-small"
Prompt format:


question: <QUESTION>
context: <RETRIEVED PASSAGES>
answer:
Generation uses beam search with deterministic settings.

RAG Pipeline
Defined in a single helper:


generate_rag_answer(question, retriever, top_k=3)
Retrieve passages

Trim sentences

Build unified prompt

Generate answer

Returns:

model output

used context

retriever metadata

6. Evaluation
Retrieval Metrics
Precision@5

Recall@5

Computed using HotpotQA’s supporting fact titles.

Generation Metrics
Computed over the first 50 examples:

BLEU (sacrebleu)

ROUGE-L (rouge-score)

BERTScore-F1 (bert-score)

All metrics are logged to rag_results_summary.json.

7. Logging
Two types of logs are generated:

Global experiment summary
→ rag_results_summary.json
Contains retrieval + generation metrics with timestamp.

Qualitative examples
→ rag_qualitative_examples_bm25.json
Used for report's faithful vs hallucinated examples.

8. Visualization
Plots generated:

Retrieval Metrics Bar Chart
retrieval_metrics.png

Generation Metrics Bar Chart
generation_metrics.png

Both figures are directly used in the LaTeX report.

9. How to Run
Open the notebook in Google Colab.

Set runtime to GPU (optional but recommended).

Run all cells sequentially.

Check printed metrics at the end.

Download JSON logs and PNG figures if needed.

The entire pipeline is self-contained and reproducible.

10. Limitations
FLAN-T5-small has limited multi-hop reasoning capability.

BLEU scores remain near zero due to short gold answers (“yes”, “no”, names).

Retrieval quality does not guarantee factual generation quality.

Further improvements require larger generators or dense retrievers.

```
