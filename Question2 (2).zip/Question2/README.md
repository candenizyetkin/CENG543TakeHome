# Comparative Examination of Attention Mechanisms

CENG543 – Take Home Midterm  
Author: Can Deniz Yetkin  
Advisor: Prof. Dr. Aytuğ Onan

## Overview

This project implements a **fully reproducible, research-grade sequence-to-sequence pipeline** for analyzing how different attention mechanisms influence alignment behavior and generation quality.

We compare:

- **Additive Attention (Bahdanau)**
- **Multiplicative Attention (Luong)**
- **Scaled Dot-Product Attention**

All models share a unified encoder–decoder architecture and are trained and evaluated under identical conditions on a **paraphrase generation task** using the Quora Question Pairs dataset.

The entire pipeline runs **inside a single Colab notebook**, writes all outputs to Google Drive, and is deterministic via `set_seed(42)`.

4

## Directory Structure (Auto-generated)

All project files are automatically stored under:

/content/drive/MyDrive/TakeHome543/Question2

The pipeline creates the following subfolders:

Question2/
├── data/ # tokenized JSONL snapshots
├── vocab/ # vocabulary JSON
├── checkpoints/ # trained model weights (.pt)
├── logs/ # training history, metrics, attention stats (JSON)
└── figs/ # attention heatmaps (PNG)

No manual directory creation is required.

## 1. Features

### Unified Encoder–Decoder Architecture

- Shared across all attention mechanisms
- BiLSTM encoder, LSTM decoder
- Shared vocabulary (train-only build)
- Teacher forcing during training
- Greedy decoding at inference

### Three Attention Mechanisms

Each attention is pluggable into the same decoder:

- Additive (Bahdanau)
- Multiplicative (Luong)
- Scaled Dot-Product

### Evaluation Metrics

The pipeline automatically computes:

- **BLEU**
- **ROUGE-L**
- **Perplexity (PPL)**
- **Attention Entropy (context selectivity)**

### Visualization

For each attention mechanism:

- 5+ **attention alignment heatmaps**
- Tokens labeled on both axes
- PNG files saved under `figs/`

### ✓ Deterministic Training

numpy, python, torch = seed 42
cudnn deterministic = True

### ✓ Logging

Every training run logs:

- epoch-wise train/val loss
- train/val perplexity
- inference metrics
- attention entropy statistics
- all saved as JSON into `logs/`

## 2. How to Run the Entire Pipeline (One Cell)

Inside Google Colab, run the provided **single-cell pipeline**:

# simply paste the full pipeline code block provided in the notebook

# it handles:

# - dataset loading

# - vocabulary building

# - tokenization

# - dataloaders

# - encoder–decoder definition

# - 3 attention mechanisms

# - training

# - metrics

# - visualizations

# - logging

This cell:

Mounts Google Drive

Creates project directories

Builds vocabulary

Tokenizes Quora dataset

Trains 3 separate models

Evaluates BLEU/ROUGE/PPL

Computes entropy

Visualizes alignment maps

Saves everything to Drive

3. Output Files

Training History

logs/history_bahdanau.json
logs/history_luong.json
logs/history_scaled_dot.json

Each contains:

[
{
"epoch": 1,
"train_loss": ...,
"valid_loss": ...,
"train_ppl": ...,
"valid_ppl": ...,
"time_sec": ...
},
...
]

Evaluation Metrics
,

logs/metrics_bahdanau.json
logs/metrics_luong.json
logs/metrics_scaled_dot.json
Attention Entropy

logs/attention_stats_bahdanau.json
logs/attention_stats_luong.json
logs/attention_stats_scaled_dot.json
Attention Heatmaps (PNG)

figs/attention_bahdanau_0.png
figs/attention_bahdanau_1.png
...
figs/attention_luong_0.png
...
figs/attention_scaled_dot_0.png
...
These plots illustrate alignment sharpness, context focus, and failure cases.

4. Model Training Summary
   Attention BLEU ↑ ROUGE-L ↑ Test PPL ↓ Val PPL ↓ Entropy ↓
   Bahdanau 26.30 0.539 7.3 7.2 1.942
   Luong 25.24 0.514 8.3 8.2 0.000
   Scaled Dot 26.10 0.535 7.5 7.4 1.973

Key findings:

Bahdanau performs best overall across all metrics.

Luong attention collapses to nearly one-hot distributions (entropy ≈ 0).

Scaled dot-product performs between Bahdanau and Luong.

5. Interpreting Attention Entropy
   Lower entropy → sharper attention (focus on fewer tokens)

Higher entropy → more diffuse alignment

Observations:

Bahdanau = moderate entropy, best performance

Scaled dot = slightly higher entropy, competitive

Luong = extremely low entropy, harmful oversharp focus

Entropy therefore reflects context selectivity and directly correlates with metric differences.
